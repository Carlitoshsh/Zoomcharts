function createIndex(){
  var jsonFile = JSON.parse("{ \"nodes\":" + localStorage.getItem("storageNODES") + ", \"links\":" + localStorage.getItem("storageLINKS") + "}");

  var index = lunr(function () {
    this.field('name')
    this.field('className')
    this.field('text')
    this.ref('id')
    // documents.forEach(function (doc,i) {
    jsonFile.nodes.forEach(function (doc, i) {
      // console.log(i)
      this.add({
        id:	i,
        name:	doc.name,
        className: doc.className,
        text: doc.text
      })
    }, this)
  });

  $('#closeResults').on('click',function(){
    $('#results').css('visibility','hidden')
    $('#graphContainer').css('opacity','1.0')
  })

  $('#search_input').on('keypress', function(e) {
    var jsonArr = {"results":[]};
    if (e.which == 13) {
      var searchText = document.getElementById('search_input').value;
      var results = index.search(searchText);
      results.map(function(id){
        jsonArr["results"].push(jsonFile.nodes[id.ref]);
      })
      $('#graphContainer').css('opacity','0.3')
      $('#results').css('visibility','visible')
      if (results.length > 0){
        $.get('templates/query_netchart.mst', function(template) {
          var rendered = Mustache.render(template, jsonArr);
          $('#resultContent').html(rendered);
        });
      }else{
        $('#resultContent').html("<h2>No se encontraron resultados para su búsqueda</h2>");
      }
    }
  });
}
