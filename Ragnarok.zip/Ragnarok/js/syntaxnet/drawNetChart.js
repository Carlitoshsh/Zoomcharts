function getUrlVars() {
  var vars = [], hash;
  var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
  for (var i = 0; i < hashes.length; i++) {
    hash = hashes[i].split('=');
    vars.push(hash[0]);
    vars[hash[0]] = hash[1];
  }
  return vars;
}

function drawNetChart() {

  //var dataText = "{ \"nodes\":" + localStorage.getItem("storageNODES") + ", \"links\":" + localStorage.getItem("storageLINKS") + "}";
  //var dataJSON = JSON.parse(dataText);
  // console.log(dataJSON)

  if (getUrlVars()["id"] !== undefined) {
    idSyntax = getUrlVars()["id"]
  }
  var syntaxnetGenerated = "http://10.23.228.142:9000/cloud?id=" + idSyntax
  //var syntaxnetGenerated = "http://siec.imi.mil.co/nsemantica/cloud?id=" + idSyntax
  console.log(syntaxnetGenerated)
  //console.log()

  console.log("ID = " + idSyntax)

  var t = new NetChart({
    container: document.getElementById("graphContainer"),
    area: { height: null },
    data: { url: syntaxnetGenerated },
    navigation: {
      mode: "showall",
      //initialNodes: node.,
    },
    toolbar: {
      zoomControl: true
    },
    layout: {
      mode: "hierarchy",
      //nodeSpacing: 300
    },
    interaction: {
      // resizing: { enabled: false },
      zooming: {
        zoomExtent: [0.01, 1],
        // autoZoomExtent: [null, 1],
        autoZoomExtent: [0, 4],
        autoZoomSize: 1.2,
        initialAutoZoom: "overview"
      },
    },
    advanced: {
      useAnimationFrame: false
    },
    info: {
      enabled: true,
      nodeContentsFunction: function (itemData, item) {
        return "<div style='margin:auto; width:200px; height:100%; padding': 10px;>"
          + "<h3 style='font-weight: 14; font-size: 15px; color: #2f256e; padding-bottom: 3px; margin:0px'>" +
          itemData.name + " - [" + itemData.className + "]</h3>" +
          "<div style='padding: 10px;font-size: 8;'><pre>" + itemData.text + "</pre></div>" +
          "</div>";
      }
    },
    legend: {
      enabled: true
    },
    nodeLabel: {
      borderRadius: 5,
      padding: 5,
      textStyle: {
        fillColor: "white"
      }
    },
    style: {
      nodeClasses: [
        { className: "ADJ", nameLegend: "Adjetivo", style: { display: "circle", fillColor: "rgb(216,177,181)" } },
        //{ className: "ADP", nameLegend: "Adposición", style: { display: "circle", fillColor: "rgb(50,136,189)" } },
        { className: "ADV", nameLegend: "Adverbio", style: { display: "circle", fillColor: "rgb(103,150,150)" } },
        { className: "AUX", nameLegend: "Verbo Auxiliar", style: { display: "circle", fillColor: "rgb(255,127,42)" } },
        //{ className: "CONJ", nameLegend: "Conjunción coordinante", style: { display: "circle", fillColor: "rgb(102,194,101)" } },
        //{ className: "DET", nameLegend: "Determinante", style: { display: "circle", fillColor: "#3b2f00" } },
        //{ className: "INTJ", nameLegend: "Interjección", style: { display: "circle", fillColor: "#d5783e" } },
        { className: "NOUN", nameLegend: "Nombres/Sustantivos", style: { display: "circle", fillColor: "#bcb3e5" } },
        { className: "NUM", nameLegend: "Numeral", style: { display: "circle", fillColor: "#3ed5c4" } },
        //{ className: "PART", nameLegend: "Partícula", style: { display: "circle", fillColor: "#9bd53e" } },
        { className: "PRON", nameLegend: "Pronombre", style: { display: "circle", fillColor: "#EAccF4" } },
        { className: "PROPN", nameLegend: "Nombre propio", style: { display: "circle", fillColor: "#BEF7CB" } },
        //{ className: "PUNCT", nameLegend: "Puntuación", style: { display: "circle", fillColor: "#cccccc" } },
        //{ className: "SCONJ", nameLegend: "Conjunción subordinante", style: { display: "circle", fillColor: "#2a4928" } },
        { className: "SYM", nameLegend: "Simbolo", style: { display: "circle", fillColor: "#2FA3A1" } },
        { className: "VERB", nameLegend: "Verbo", style: { display: "circle", fillColor: "#e6d244" } },
        { className: "X", nameLegend: "Otro", style: { display: "circle", fillColor: "#1a2fc2" } },
      ],
      //nodeLabel: {
      //backgroundStyle: {
      //fillColor: "#f9f9f9",
      //lineColor: "#e6e6e6"
      //}
      //},
      nodeStyleFunction: nodeStyle,
      linkStyleFunction: linkStyle,
      fadeTime: 0,
      //scaleObjectsWithZoom: true
    }
  });
}

function nodeStyle(node) {
  //node.image = node.data.image;
  node.label = node.data.name;

  node.display = "roundtext";
  node.labelStyle.textStyle = {
    shadowColor: "#e6e6e6",
    shadowBlur: 50,
    font: "24px"
  }

  node.scaleWithSize = true;
  node.scaleWithZoom = true;

  //node.customShape = setNodeShape(node.data.shape);
  // node.items = [
  //   {
  //     text: node.data.name,
  //     aspectRatio: 0,
  //     px: 0,
  //     py: 1,
  //     y: 6,
  //     textStyle: {
  //       fillColor: "black",
  //       font: "10px"
  //     },
  //     scaleWithSize: true,
  //     scaleWithZoom: true,
  //     maxWidth: 100,
  //     backgroundStyle: {
  //       fillColor: "#f9f9f9",
  //       lineColor: "#e6e6e6"
  //     },
  //     py: 1.2
  //   }
  // ];
}

function linkStyle(link) {
  link.length = 2;
  link.fromDecoration = "circle";
  link.toDecoration = "arrow";
  link.items = [
    {   // Default item places just as the regular label.
      text: link.data.type,
      padding: 2,
      backgroundStyle: {
        fillColor: "rgba(86,185,247,1)",
        lineColor: "rgba(86,185,247,0.4)"
      },
      textStyle: {
        fillColor: "white"
      }
    }
  ]
}
