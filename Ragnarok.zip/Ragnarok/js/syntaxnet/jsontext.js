function getUrlVarsBrat()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

// Show JSON
var idSyntax 

if(getUrlVarsBrat()["id"] !== undefined){
    idSyntax = getUrlVarsBrat()["id"] 
    //alert("ID: "+id)
}

//document.getElementById("iframe-brat").src = "http://siec.imi.mil.co/brat/#/"+idSyntax
document.getElementById("iframe-brat").src = "http://10.23.228.137/#/"+idSyntax

// document.getElementById('queryResult').style.height = '150px'
// document.getElementById('queryResult').style.width = '100%'
// document.getElementById('queryResult').style.overflow = "hidden"

$("#toGraph").on('click', function(e){
    e.preventDefault;
    $("#loader").show();
    //$.post("http://siec.imi.mil.co/nsemantica/execute", $("#syntax_form").serialize(), function(data) {
    $.post("http://10.23.228.142:9000/execute", $("#syntax_form").serialize(), function(data) {
        $("#loader").hide();    
        idSyntax = data.id
        console.log("Generated = " + idSyntax)
        $("#tabS").removeClass("is-active")
        $("#tabG").addClass("is-active")
        $("#syntaxnet-panel").removeClass("is-active")
        $("#graph-panel").addClass("is-active")
        document.getElementById("iframe-brat").src = "http://10.23.228.137/#/"+idSyntax
        // document.getElementById("iframe-brat").css( {'height':'50%',
        // 'width': '50%'})
        //$('#brat-panel').load("http://10.23.228.137/#/"+idSyntax+" #svg")
        drawNetChart()
    })

})

$("#knn_test").on('click', function(e) {
    e.preventDefault;
    //$.post("http://siec.imi.mil.co/nsemantica/getKnn", $("#knn_form").serialize(), function(data) {
    $.post("http://10.23.228.142:9000/getKnn", $('#knn_form').serialize(), function(data) {
        //document.getElementById("queryResult").innerText = JSON.stringify(data.neighbors);

        //console.log(data.neighbors)

        var hdata = data.neighbors
        var knnData = []
        hdata.forEach(function(e){
            knnData.push([e])
        })
        console.log(knnData)

        if(hdata != null){
            var container = document.getElementById('queryResult')
            var hot = new Handsontable(container, 
                {
                    data: knnData,
                    dataSchema: {
                        distance: ""
                    },
                    columns: [
                        
                        {
                            data: 0,
                            readOnly: true,
                        }
                        /*,{
                            data: "distance",
                            readOnly: true,
                        },*/
                    ],
                    //rowHeaders: true,
                    colHeaders: ["Palabra relacionada"],
                    colWidth: [250],
                    stretchH: "all",
                    manualColumnResize: true,

                })

     
            hot.render();
        } else {
            document.getElementById('queryResult').innerText = "No hay resultados"
        }
        
       
    }, 'json')
})


function myFunction(){
    var JSONtext = "{ \"nodes\":" + JSON.stringify(hot.getSourceData()) + ", \"links\":" + JSON.stringify(hot2.getSourceData()) + "}";
    document.getElementById("p1").innerHTML = JSONtext;
}
