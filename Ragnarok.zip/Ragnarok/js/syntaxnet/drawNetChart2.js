function drawNetChart2() {


  var propertiesClasses = {
    "ADJ":["Adjetivo","rectangle","rgb(213,62,79)" ],
    "ADP":["Adposición","rectangle","rgb(50,136,189)" ],
    "ADV":["Adverbio","rectangle","rgb(77,77,77)" ],
    "AUX":["Verbo Auxiliar","rectangle","rgb(255,127,42)" ],
    "CONJ":["Conjunción coordinante","rectangle","rgb(102,194,101)" ],
    "DET":["Determinante","rectangle","rgb(255,204,0)" ],
    "INTJ":["Interjección","rectangle","#d5783e" ],
    "NOUN":["Sustantivo/Nombre","rectangle","#bcb3e5" ],
    "NUM":["Numeral","rectangle","#3ed5c4" ],
    "PART":["Partícula","rectangle","#9bd53e" ],
    "PRON":["Pronombre","rectangle","#E9C5B4" ],
    "PROPN":["Nombre propio","rectangle","#BEF7CB" ],
    "PUNCT":["Puntuación","rectangle","#5F9085" ],
    "SCONJ":["Conjunción subordinante","rectangle","#2a4928" ],
    "SYM":["Simbolo","rectangle","#2FA3A1" ],
    "VERB":["Verbo","rectangle","#e6d244" ],
    "X":["Otro","rectangle","#1a2fc2" ]
  };

  var dataText = "{ \"nodes\":" + localStorage.getItem("storageNODES") + ", \"links\":" + localStorage.getItem("storageLINKS") + "}";
  var dataJSON = JSON.parse(dataText);
  console.log(dataJSON)
  // var syntaxnetGenerated = "http://10.23.228.142:9000/cloud?id=" + idSyntax
  // console.log(syntaxnetGenerated)

  //console.log("ID = " + idSyntax)
  var t = new NetChart({
    container: document.getElementById("graphContainer"),
    area: { height: null },
    data: { preloaded: dataJSON },
    navigation: {
      mode: "showall",
      initialNodes: ["1"],
    },
    layout: {
      mode: "radial",
      nodeSpacing: 300
    },
    // interaction: {
    //   // resizing: { enabled: false },
    //   zooming: {
    //     zoomExtent: [0.01, 2],
    //     // autoZoomExtent: [null, 1],
    //     autoZoomExtent: [0, 1],
    //     // autoZoomSize: 1
    //     // initialAutoZoom: "overview"
    //   },
    // },
    advanced: {
      useAnimationFrame: false
    },
    info: {
      enabled: true,
      nodeContentsFunction: function (itemData, item) {
        return "<div style='margin:auto; width:200px; height:100%; padding': 10px;>" +
          ""
          + "<h3 style='font-weight: 14; font-size: 15px; color: #2f256e; padding-bottom: 3px; margin:0px'>" + itemData.name + "</h3>" +
          "<div class='div_image_tooltip'></div><div class='div_text_tooltip'><p class='text_tooltip' style='font-size:12px; padding: 15%;'>" + itemData.text + "</p></div>" +
          "</div>";
      }
    },
    legend: {
      enabled: true
    },
    nodeLabel: {
      borderRadius: 5,
      padding: 5,
      textStyle: {
        fillColor: "white"
      }
    },
    style: {
      /* 
          Check if COMPONENT to add
          nodeStyleFunction
        */
      nodeClasses: [
        
        { className: "ADJ", nameLegend: "Adjetivo", style: { display: "rectangle", fillColor: "rgb(213,62,79)" } },
        { className: "ADP", nameLegend: "Adposición", style: { display: "rectangle", fillColor: "rgb(50,136,189)" } },
        { className: "ADV", nameLegend: "Adverbio", style: { display: "rectangle", fillColor: "rgb(77,77,77)" } },
        { className: "AUX", nameLegend: "Verbo Auxiliar", style: { display: "rectangle", fillColor: "rgb(255,127,42)" } },
        { className: "CONJ", nameLegend: "Conjunción coordinante", style: { display: "rectangle", fillColor: "rgb(102,194,101)" } },
        { className: "DET", nameLegend: "Determinante", style: { display: "rectangle", fillColor: "rgb(255,204,0)" } },
        { className: "INTJ", nameLegend: "Interjección", style: { display: "rectangle", fillColor: "#d5783e" } },
        { className: "NOUN", nameLegend: "Sustantivo/Nombre", style: { display: "rectangle", fillColor: "#bcb3e5" } },
        { className: "NUM", nameLegend: "Numeral", style: { display: "rectangle", fillColor: "#3ed5c4" } },
        { className: "PART", nameLegend: "Partícula", style: { display: "rectangle", fillColor: "#9bd53e" } },
        { className: "PRON", nameLegend: "Pronombre", style: { display: "rectangle", fillColor: "#E9C5B4" } },
        { className: "PROPN", nameLegend: "Nombre propio", style: { display: "rectangle", fillColor: "#BEF7CB" } },
        { className: "PUNCT", nameLegend: "Puntuación", style: { display: "rectangle", fillColor: "#5F9085" } },
        { className: "SCONJ", nameLegend: "Conjunción subordinante", style: { display: "rectangle", fillColor: "#2a4928" } },
        { className: "SYM", nameLegend: "Simbolo", style: { display: "rectangle", fillColor: "#2FA3A1" } },
        { className: "VERB", nameLegend: "Verbo", style: { display: "rectangle", fillColor: "#e6d244" } },
        { className: "X", nameLegend: "Otro", style: { display: "rectangle", fillColor: "#1a2fc2" } },
      ],
      //nodeLabel: {
        //backgroundStyle: {
          //fillColor: "#f9f9f9",
          //lineColor: "#e6e6e6"
        //}
      //},
      nodeStyleFunction: nodeStyle,
      linkStyleFunction: linkStyle,
      fadeTime: 0,
      // scaleObjectsWithZoom: false
    }
  });
}

function nodeStyle(node) {
  //node.image = node.data.image;
  node.label = node.data.name + "\n" + node.data.text;
  node.display = "roundtext";
  node.labelStyle.textStyle = {
    shadowColor: "#e6e6e6",
    shadowBlur: 50
  }
  //node.customShape = node.data.shape;
  // node.items = [
  //   {
  //     //text: node.data.name,
  //     aspectRatio: 0,
  //     px: 0,
  //     py: 1,
  //     y: 6,
  //     textStyle: {
  //       fillColor: "black"
  //       // font: "24px"
  //     },
  //     scaleWithSize: true,
  //     scaleWithZoom: true,
  //     maxWidth: 100,
  //     backgroundStyle: {
  //       fillColor: "#f9f9f9",
  //       lineColor: "#e6e6e6"
  //     },
  //     py: 1.2
  //   }
  // ];
}

function linkStyle(link) {
  link.length = 2;
  link.fromDecoration = "circle";
  link.toDecoration = "arrow";
  link.items = [
    {   // Default item places just as the regular label.
      text: link.data.type,
      padding: 2,
      backgroundStyle: {
        fillColor: "rgba(86,185,247,1)",
        lineColor: "rgba(86,185,247,0.4)"
      },
      textStyle: {
        fillColor: "white"
      }
    }
  ]
}
